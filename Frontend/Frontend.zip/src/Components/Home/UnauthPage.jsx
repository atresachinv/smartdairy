import React from "react";

const UnauthPage = () => {
  return (
    <div className="w100 h1 d-flex-col center">
      <span className="title">Unauthorized User!</span>
      <span className="heading">
        Sorry You Are Not Allow To Access This Page!
      </span>
    </div>
  );
};

export default UnauthPage;
