import React from "react";

const CenterReports = () => {
  return (
    <div>
      <span>CenterReports</span>
    </div>
  );
};

export default CenterReports;
