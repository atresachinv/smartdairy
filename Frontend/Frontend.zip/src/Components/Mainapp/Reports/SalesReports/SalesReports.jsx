import React from "react";

const SalesReports = () => {
  return (
    <div>
      <span>SalesReports</span>
    </div>
  );
};

export default SalesReports;
