import React from "react";

const PaymentReports = () => {
  return (
    <div>
      <span>PaymentReports</span>
    </div>
  );
};

export default PaymentReports;
