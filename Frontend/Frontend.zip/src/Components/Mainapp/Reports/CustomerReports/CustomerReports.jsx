import React from "react";

const CustomerReports = () => {
  return (
    <div>
      <span>CustomerReports</span>
    </div>
  );
};

export default CustomerReports;
