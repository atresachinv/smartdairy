import React from "react";

const EmpReports = () => {
  return (
    <div>
      <span>EmpReports</span>
    </div>
  );
};

export default EmpReports;
