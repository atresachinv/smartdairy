import React from "react";

const InventoryRports = () => {
  return (
    <div>
      <span>InventoryRports</span>
    </div>
  );
};

export default InventoryRports;
