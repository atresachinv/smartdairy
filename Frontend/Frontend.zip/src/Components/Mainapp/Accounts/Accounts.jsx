import React from "react";

const Accounts = () => {
  return (
    <div>
      <h3>Accounts</h3>
    </div>
  );
};

export default Accounts;
