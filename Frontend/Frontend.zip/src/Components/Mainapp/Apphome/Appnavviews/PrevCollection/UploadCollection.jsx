import React from "react";

const UploadCollection = () => {
  return (
    <div>
      <span>Upload Collection</span>
    </div>
  );
};

export default UploadCollection;
