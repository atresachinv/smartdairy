import React from "react";

const PrevCollectionList = () => {
  return (
    <div>
      <span>Prev Collection List</span>
    </div>
  );
};

export default PrevCollectionList;
