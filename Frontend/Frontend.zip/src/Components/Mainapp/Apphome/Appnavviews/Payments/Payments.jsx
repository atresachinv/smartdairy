import React from "react";

const Payments = () => {
  return (
    <div className="payment-container">
      <div className="title-container w100 h10 p10">
        <h2 className="subtitle">Payments</h2>
      </div>
    </div>
  );
};

export default Payments;
