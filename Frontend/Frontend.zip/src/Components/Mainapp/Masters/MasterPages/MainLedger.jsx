import React from 'react'

const MainLedger = () => {
  return (
    <div>
      <span>MainLedger</span>
    </div>
  );
}

export default MainLedger
