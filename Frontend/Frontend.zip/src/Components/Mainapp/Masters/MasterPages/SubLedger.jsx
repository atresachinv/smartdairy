import React from 'react'

const SubLedger = () => {
  return (
    <div>
      <span>SubLedger</span>
    </div>
  );
}

export default SubLedger
