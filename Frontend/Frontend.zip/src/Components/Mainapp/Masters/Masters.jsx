import React from "react";

const Masters = () => {
 
  return (
    <div>
      <span>Masters</span>

    </div>
  );
};

export default Masters;
