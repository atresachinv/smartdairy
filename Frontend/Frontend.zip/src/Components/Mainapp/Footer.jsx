import React from "react";

const Footer = () => {
  return (
    <>
      <span className="text t-center">
        All © Copyrights Reserved By Vikern Software Technology @2024.
      </span>
    </>
  );
};

export default Footer;
