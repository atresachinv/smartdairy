import React from "react";

const DairySettings = () => {
  return (
    <div>
      <span>DairySettings DairySettings</span>
    </div>
  );
};

export default DairySettings;
