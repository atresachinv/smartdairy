import React from "react";

const MachineSettings = () => {
  return (
    <div>
      <span>MachineSettings MachineSettings</span>
    </div>
  );
};

export default MachineSettings;
