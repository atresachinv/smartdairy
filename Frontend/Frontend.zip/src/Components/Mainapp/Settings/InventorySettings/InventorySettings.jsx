import React from 'react'

const InventorySettings = () => {
  return (
    <div>
      <span>InventorySettings InventorySettings</span>
    </div>
  );
}

export default InventorySettings
