import React from "react";

const ProductList = () => {
  return (
    <div>
      <span>ProductList ProductList</span>
    </div>
  );
};

export default ProductList;
