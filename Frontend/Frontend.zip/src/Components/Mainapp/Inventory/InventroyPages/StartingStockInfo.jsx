import React from "react";

const StartingStockInfo = () => {
  return (
    <div>
      <span>StartingStockInfo StartingStockInfo</span>
    </div>
  );
};

export default StartingStockInfo;
