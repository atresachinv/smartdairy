import React from "react";

const ProductSale = () => {
  return (
    <div>
      <span>ProductSale ProductSale</span>
    </div>
  );
};

export default ProductSale;
