import React from "react";

const ProductPurchase = () => {
  return (
    <div>
      <span>ProductPurchase ProductPurchase</span>
    </div>
  );
};

export default ProductPurchase;
