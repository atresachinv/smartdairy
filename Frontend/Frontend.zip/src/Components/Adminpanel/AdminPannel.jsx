import React from "react";

const AdminPannel = () => {
  return (
    <div>
      <div className="title">Welcome to Admin Pannel</div>
    </div>
  );
};

export default AdminPannel;
